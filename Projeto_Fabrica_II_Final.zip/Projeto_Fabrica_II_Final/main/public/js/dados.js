
$(document).ready(function () {
    // mascara CPF 
    $(".cpf-m").mask('000.000.000-00', { reverse: false });
    // mascara RG
    $('.rg-m').mask('00.000.000-0', { reverse: false });
    // mascara CEP
    $('.cep-m').mask('00000-000', { reverse: false });
    // mascara celular
    $('.cel-m').mask('(00) 00000-0000', { reverse: false });
    // mascara titulo eleitor
    $('.ele-m').mask('0000 0000 0000', { reverse: false });
});

