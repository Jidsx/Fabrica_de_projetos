console.log("É difícil ser Corinthiano");
