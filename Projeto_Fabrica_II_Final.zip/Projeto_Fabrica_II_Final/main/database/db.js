const mysql = require('mysql');
const connection = mysql.createConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    port: process.env.DB_PORT

});

connection.connect((error)=>{
    if(error){
        console.log('O erro de conexão é : ' + error);
        return;
    }
    console.log('Conectado a Base de Dados')
});

module.exports = connection;

// Create database Ust;
// use Ust;

// Create table alunos (
//     id int primary key auto_increment,
//     email varchar(55) unique,
//     senha varchar(255),
//        nome VARCHAR(100) ,
//        cpf VARCHAR(20) ,
//        rg VARCHAR(20) ,
//        endereco VARCHAR(255) ,
//        cep VARCHAR(20) ,
//        celular VARCHAR(20) ,
//        eleitor VARCHAR(25) ,
//        instituicao VARCHAR(255) ,
//        curso VARCHAR(100) 
//     );
  