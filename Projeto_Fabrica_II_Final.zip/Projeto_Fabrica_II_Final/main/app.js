// 1 - Invocando o Express
const express = require('express');
const app = express();

// 2 - Setando urlencoded para capturar os dados do formulario
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// 3 - Invocando o dotenv
require('dotenv').config({ path: './env/.env' });

// 4 - Diretorio Publico
app.use('/resources', express.static('public'));
app.use('/resources', express.static(__dirname + '/public'));


// 5 - Estabelecendo o mecanisno de modelo ejs
app.set('view engine', 'ejs');


// 6 - Invocando o bcryptjs, para segurança 
const bcryptjs = require('bcryptjs');

// 7 - Var. de session
const session = require('express-session');
app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true
}));

// 8 - Invocando o modulo de conexao ao Banco de Dados
const connection = require('./database/db');

// 9 - Estabelecendo os caminhos

app.get('/', (req, res) => {
  res.render('index');
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.get('/cadastro', (req, res) => {
  res.render('cadastro');
});

app.get('/dadosComplementar', (req, res) => {
  res.render('dadosComplementar');
});

app.get('/telaProtocolo', (req, res) => {
  res.render('telaProtocolo');
});

// 10 - Registrar, parte do Cadastro
app.post('/cadastro', async (req, res) => {
  const email = req.body.email;
  const senha = req.body.senha;
  let senhaHash = await bcryptjs.hash(senha, 8);
  connection.query('INSERT INTO alunos set ?', { email: email, senha: senhaHash },
    async (error, results) => {
      if (error) {
        console.log(error);
      }
      else {
        res.render('cadastro', {
          alert: true,
          alerTitle: "Cadastrado",
          alertMessage: "Cadastro Realizado com Sucesso!",
          alertIcon: 'success',
          showConfirmButton: false,
          timer: 2000,
          rota: ''
        });
      }
    })
});

// 11 - Autenticação parte do login
app.post('/auth', async (req, res) => {
  const email = req.body.email;
  const senha = req.body.senha;
  if (email && senha) {
    connection.query('SELECT * FROM alunos WHERE email = ?', [email], async (error, results) => {
      if (results.length > 0 && (await bcryptjs.compare(senha, results[0].senha))) {
        
        req.session.userId = results[0].id; // Armazena o ID do usuário na sessão

        // Verifica se o usuário ja preencheu os dados 
        connection.query('SELECT * FROM alunos WHERE id = ?', [results[0].id], async (error, results) => {
          if (results[0].nome && results[0].cpf && results[0].rg && results[0].endereco && results[0].cep && results[0].celular && results[0].eleitor && results[0].instituicao && results[0].curso) {
            res.render('login', {
              alert: true,
              alertTitle: "Login",
              alertMessage: "Login Realizado com Sucesso!",
              alertIcon: 'success',
              showConfirmButton: false,
              timer: 2000,
              rota: 'telaProtocolo'
            });
          } else {
            res.render('login', {
              alert: true,
              alertTitle: "Login",
              alertMessage: "Login Realizado com Sucesso!",
              alertIcon: 'success',
              showConfirmButton: false,
              timer: 2000,
              rota: 'dadosComplementar'
            });
          }
        });
      } else {
        res.render('login', {
          alert: true,
          alertTitle: "Erro",
          alertMessage: "Email ou Senha Incorretos!",
          alertIcon: 'error',
          showConfirmButton: true,
          timer: false,
          rota: 'login'
        });
      }
    });
  } else {
    
  }
});

// 12 - Pegando os dados Complementares
app.post('/telaProtocolo', async (req, res) => {
  const nome = req.body.nome;
  const cpf = req.body.cpf;
  const rg = req.body.rg;
  const endereco = req.body.endereco;
  const cep = req.body.cep;
  const celular = req.body.celular;
  const eleitor = req.body.eleitor;
  const instituicao = req.body.instituicao;
  const curso = req.body.curso;

  const userId = req.session.userId; // Obtendoo ID armazenado no login

  connection.query('UPDATE alunos SET ? WHERE id = ?', [{
    nome: nome, cpf: cpf, rg: rg, endereco: endereco, cep: cep,
    celular: celular, eleitor: eleitor, instituicao: instituicao, curso: curso
  }, userId],
    async (error, results) => {
      if (error) {
        console.log(error);
      } else {
        res.render('dadosComplementar', {
          alert: true,
          alertTitle: "Solicitação",
          alertMessage: "Solicitação Enviada com Sucesso!",
          alertIcon: 'success',
          showConfirmButton: false,
          timer: 2000,
          rota: 'telaProtocolo',
          
        });
      }
    });
});

app.listen(3000, (req, res) => {
  console.log('Servidor Rodando em http://localhost:3000')
});